package com.example.recyclerview1.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview1.R
import com.example.recyclerview1.model.recyclerview1


class ItemAdapter(
    private val context: Context,
    private val dataset: List<recyclerview1>
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {
    // Text
    class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        val textViewNames: TextView = view.findViewById(R.id.names)
        val textViewDes: TextView=view.findViewById((R.id.dess))
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        // create a new view
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)

        return ItemViewHolder(adapterLayout)
    }
    //Text
     override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        Log.d("1123","onbind viewhodler $position")
         val item = dataset[position]
         holder.textViewNames.text =  context.resources.getString(item.stringResourceId)//change
        holder.textViewDes.text=context.resources.getString(item.stringResourceId2)//change
     }


    override fun getItemCount() = dataset.size
}