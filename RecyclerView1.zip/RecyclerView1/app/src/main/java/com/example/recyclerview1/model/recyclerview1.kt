package com.example.recyclerview1.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class recyclerview1(
    @StringRes val stringResourceId: Int,
    @StringRes val stringResourceId2: Int
)