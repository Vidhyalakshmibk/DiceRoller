package com.example.recyclerview1.data

import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview1.R
import com.example.recyclerview1.model.recyclerview1

class Datasource {
    fun loadAffirmations(): List<recyclerview1> {
        return listOf<recyclerview1>(
            recyclerview1(R.string.name1,R.string.des1),
            recyclerview1(R.string.name2,R.string.des2),
            recyclerview1(R.string.name3,R.string.des3),
            recyclerview1(R.string.name4,R.string.des4),
            recyclerview1(R.string.name5,R.string.des5),
            recyclerview1(R.string.name6,R.string.des6),
            recyclerview1(R.string.name7,R.string.des7),
            recyclerview1(R.string.name8,R.string.des8),
            recyclerview1(R.string.name9,R.string.des9),
            recyclerview1(R.string.name10,R.string.des10),
            recyclerview1(R.string.name11,R.string.des11),
            recyclerview1(R.string.name12,R.string.des12),
            recyclerview1(R.string.name13,R.string.des13),
            recyclerview1(R.string.name14,R.string.des14),
            recyclerview1(R.string.name15,R.string.des15),
            recyclerview1(R.string.name16,R.string.des16),
            recyclerview1(R.string.name17,R.string.des17)




        )
    }
}