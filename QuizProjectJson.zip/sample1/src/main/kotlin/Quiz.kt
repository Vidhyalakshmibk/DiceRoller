import org.json.JSONArray
import org.json.JSONTokener

class Quiz{
    val qa = """[
    {
        "Qn": "When is our Independence day celebrated?   a)August 15    b)February 26    c)january 26",
        "Ans": "a"
    },
    {
        "Qn": "When is our Republic day celebrated?    a)August 15    b)February 26    c)january 26",
        "Ans": "c"
    },
    {
        "Qn": "if a=2 and b=5, then (a + b) is ______   a)6    b)7   c)3",
        "Ans": "b"
    },
    {
        "Qn": "if a=2 and b=5, then (a - b) is ______   a)6    b)7   c)-3",
        "Ans": "c"
    }
    
]"""
}

fun main(){
    val obj=Quiz()
    val jsonArray = JSONTokener(obj.qa).nextValue() as JSONArray
    var score:Int=0
    var ans:String?=""
    for (i in 0 until jsonArray.length()) {

        // Employee Name
        val question:String = jsonArray.getJSONObject(i).getString("Qn")
        print("\nQuestion ${i+1}: "+ question)
        print("\nEnter your answer ( a , b, c ): ")
        ans=readLine()
        if(ans.equals(jsonArray.getJSONObject(i).getString("Ans"),true)){
            score+=1
        }

    }
    print("Score:    $score")
}

