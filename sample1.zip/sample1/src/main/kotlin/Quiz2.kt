import org.json.JSONArray
import org.json.JSONObject

fun main(){
    val jobj1= JSONObject()
    jobj1.put("Qn","When is our Independence day celebrated?   a)August 15    b)February 26    c)january 26")
    jobj1.put("Ans","a")
   // print("\n $jobj1")
    val jobj2= JSONObject()
    jobj2.put("Qn","When is our Republic day celebrated?    a)August 15    b)February 26    c)january 26")
    jobj2.put("Ans","c")
    //print("\n $jobj2")
    val jobj3= JSONObject()
    jobj3.put("Qn","if a=2 and b=5, then (a + b) is ______   a)6    b)7   c)3")
    jobj3.put("Ans","b")
   // print("\n $jobj3")
    val jobj4= JSONObject()
    jobj4.put("Qn","if a=2 and b=5, then (a - b) is ______   a)6    b)7   c)-3")
    jobj4.put("Ans","c")
    //print("\n $jobj4")
    val jArr=JSONArray()
    jArr.put(jobj1)
    jArr.put(jobj2)
    jArr.put(jobj3)
    jArr.put(jobj4)
   // print("\n $jArr")
    var score:Int=0
    var ans:String?=""
  //  labelOne@ fun quizmethod()
    var i:Int=0
    labelOne@while(i<jArr.length()) {

            val question:String = jArr.getJSONObject(i).getString("Qn")
            print("\n\nQuestion ${i+1}: "+ question)
            print("\nEnter your answer ( a , b, c ): ")
            ans=readLine()


        val answer=jArr.getJSONObject(i).getString("Ans")
        if(ans in listOf<String>("a", "b", "c")){

        }
        if(ans.equals("a",true) || ans.equals("b",true) || ans.equals("c",true)){
            if(ans.equals(answer,true)){
                score+=1

            }
        }
        else{
            print("\nThis option is not available. Please, click the correct option")
            //i--
            continue@labelOne
        }
        i++


    }
    print("Score:    $score out of ${jArr.length()}")




}