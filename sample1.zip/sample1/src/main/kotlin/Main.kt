import org.json.JSONArray
import org.json.JSONTokener

fun main() {

    val qa = """[
    {
        "id": "1",
        "employee_name": "Tiger Nixon",
        "employee_salary": "320800",
        "employee_age": "61"
    },
    {
        "id": "2",
        "employee_name": "Garrett Winters",
        "employee_salary": "170750",
        "employee_age": "63"
    }
    
]"""


    val jsonArray = JSONTokener(qa).nextValue() as JSONArray
    for (i in 0 until jsonArray.length()) {
        // ID
        val id = jsonArray.getJSONObject(i).getString("id")
        print("ID: "+ id)

        // Employee Name
        val employeeName = jsonArray.getJSONObject(i).getString("employee_name")
        print("\nEmployee Name: "+ employeeName)

        // Employee Salary
        val employeeSalary = jsonArray.getJSONObject(i).getString("employee_salary")
        print("\nEmployee Salary: "+employeeSalary)

        // Employee Age
        val employeeAge = jsonArray.getJSONObject(i).getString("employee_age")
        print("\nEmployee Age: "+ employeeAge)


    }


}