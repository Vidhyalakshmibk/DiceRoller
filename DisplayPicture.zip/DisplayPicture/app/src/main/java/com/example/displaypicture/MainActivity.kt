package com.example.displaypicture
import android.content.Context
import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.annotation.StringRes




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val nametext:TextView=findViewById(R.id.textView1)
        val dptext:TextView=findViewById(R.id.textView)
        var fname:String=getString(R.string.name)
        dptext.text= fname[0].toString()
    }
}


